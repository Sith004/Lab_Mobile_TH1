package com.example.sithlab8;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class M001ActProfile extends AppCompatActivity {

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.m001_act_profile);

        ImageView btnCall1 = findViewById(R.id.btn_call1);
        TextView tvPhone1 = findViewById(R.id.tv_phone1);
        TextView tvPhone2 = findViewById(R.id.tv_phone2);

        ImageView btnEmail = findViewById(R.id.btn_email);
        TextView tvEmail = findViewById(R.id.tv_email);

        btnCall1.setOnClickListener(v -> {
            String phone = tvPhone1.getText().toString();
            Intent i = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + phone));
            startActivity(i);
        });

        tvPhone2.setOnClickListener(v -> {
            String phone = tvPhone2.getText().toString();
            Intent i = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + phone));
            startActivity(i);
        });

        btnEmail.setOnClickListener(v -> {
            String email = tvEmail.getText().toString();
            Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + email));
            startActivity(Intent.createChooser(i, "Send email"));
        });
    }
}
