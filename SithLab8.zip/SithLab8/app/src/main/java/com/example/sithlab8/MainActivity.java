package com.example.sithlab8;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        Button btnSplash = findViewById(R.id.btn_open_splash);
        Button btnProfile = findViewById(R.id.btn_open_profile);

        btnSplash.setOnClickListener(v ->
                startActivity(new Intent(this, M000ActSplash.class)));

        btnProfile.setOnClickListener(v ->
                startActivity(new Intent(this, M001ActProfile.class)));
    }
}
