package com.example.sithlab8;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.activity.EdgeToEdge;
import androidx.annotation.DrawableRes;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.Random;

public class M000ActSplash extends AppCompatActivity {

    private final int[] COLOR_IDS = new int[]{
            R.color.splash_1, R.color.splash_2, R.color.splash_3, R.color.splash_4
    };

    private final @DrawableRes int[] ICON_IDS = new int[]{
            R.drawable.ic_penguin, R.drawable.ic_cat, R.drawable.ic_dog
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.m000_act_splash);

        LinearLayout splashRoot = findViewById(R.id.splash_root);
        ImageView imgIcon = findViewById(R.id.img_icon);

        Random rd = new Random();

        // Random màu nền
        int colorId = COLOR_IDS[rd.nextInt(COLOR_IDS.length)];
        splashRoot.setBackgroundColor(ContextCompat.getColor(this, colorId));

        // Random icon
        int iconId = ICON_IDS[rd.nextInt(ICON_IDS.length)];
        Drawable icon = ContextCompat.getDrawable(this, iconId);
        imgIcon.setImageDrawable(icon);

        // Bật overlay loading 2s (Bài 2)
        findViewById(R.id.loading_view).setVisibility(android.view.View.VISIBLE);
        new Handler().postDelayed(() ->
                findViewById(R.id.loading_view).setVisibility(android.view.View.GONE), 2000);
    }
}
