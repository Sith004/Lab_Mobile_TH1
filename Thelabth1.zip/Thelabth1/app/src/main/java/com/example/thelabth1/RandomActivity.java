package com.example.thelabth1;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import java.util.Random;

public class RandomActivity extends AppCompatActivity {

    ImageView imgDice;
    Button btnRoll;
    Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_random);

        imgDice = findViewById(R.id.imgDice);
        btnRoll = findViewById(R.id.btnRoll);

        btnRoll.setOnClickListener(v -> {
            int number = random.nextInt(6) + 1; // từ 1 đến 6
            int resId = getResources().getIdentifier("dice_" + number, "drawable", getPackageName());
            imgDice.setImageResource(resId);
        });
    }
}
