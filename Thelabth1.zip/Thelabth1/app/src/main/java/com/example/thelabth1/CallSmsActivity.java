package com.example.thelabth1;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;

public class CallSmsActivity extends AppCompatActivity {

    EditText edtPhone, edtMessage;
    Button btnCall, btnSms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call_sms);

        edtPhone = findViewById(R.id.edtPhone);
        edtMessage = findViewById(R.id.edtMessage);
        btnCall = findViewById(R.id.btnCall);
        btnSms = findViewById(R.id.btnSms);

        btnCall.setOnClickListener(v -> {
            String phone = edtPhone.getText().toString().trim();
            if (phone.isEmpty()) {
                Toast.makeText(this, "Vui lòng nhập số điện thoại", Toast.LENGTH_SHORT).show();
            } else {
                Intent callIntent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + phone));
                startActivity(callIntent);
            }
        });

        btnSms.setOnClickListener(v -> {
            String phone = edtPhone.getText().toString().trim();
            String message = edtMessage.getText().toString().trim();
            if (phone.isEmpty() || message.isEmpty()) {
                Toast.makeText(this, "Vui lòng nhập số và nội dung tin nhắn", Toast.LENGTH_SHORT).show();
            } else {
                Intent smsIntent = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + phone));
                smsIntent.putExtra("sms_body", message);
                startActivity(smsIntent);
            }
        });
    }
}
